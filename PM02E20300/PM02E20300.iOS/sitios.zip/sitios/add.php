<?php

header("Content-Type: application/x-www-form-urlencoded");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'apiSitios.php';

$api = new ApiSitios();

    //Si mi peticion es de tipo POST hago mi add
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        //Codigo nuevo
        $data   = json_decode(file_get_contents( "php://input" ),true);

        try{
            //Mapeo los datos de mi JSON recibido
            $encabezadoDescripcion = $data["Descripcion"];
            $encabezadoLatitud = $data["Latitud"];
            $encabezadoLongitud = $data["Longitud"];

            $encabezadoFoto = $data["Foto"];
            $encabezadoAudio = $data["Audio"];

            //Convertir Base 64 a Bitmap
           
            //$encabezadoFoto = base64_decode($data["Foto"]);
            //file_put_contents("Foto.jpg", $encabezadoFoto);

            //$encabezadoAudio = base64_decode($data["Audio"]);
            //file_put_contents("audio.wav", $encabezadoAudio);

           /* $encabezadoFoto = base64_decode($data["Foto"]);
            //Creo la imagen en fisico
            file_put_contents("Foto.jpg", $encabezadoFoto);

            $encabezadoAudio = $data["Audio"];

            //Reducir tamaño 

            $rutaImagenOriginal = "Foto.jpg";
            # La abrimos como un recurso. Nota: uso imagecreatefromjpeg porque es una JPEG, si fuera
            # una PNG, usa imagecreatefrompng
            $imagenOriginal = imagecreatefromjpeg($rutaImagenOriginal);

            # Y la volvemos a guardar usando imagejpeg indicando la calidad como tercer argumento
            # Lo mismo, lo hago con imagejpeg porque es JPEG, si fuera PNG ya sabes, ¿cierto?
            $rutaImagenComprimida = "comprimida.jpg";
            $calidad = 20; // Valor entre 0 y 100. Mayor calidad, mayor peso
            //Aqui reduzco tamaño y convierto a base 64
            $encabezadoFoto = base64_encode(imagejpeg($imagenOriginal, $rutaImagenComprimida, $calidad));
            
            //printf("La imagen comprimida ha sido guardada en %s", $rutaImagenComprimida);*/

            //Lleno mi array 
            $item = array(

                'descripcion' => $encabezadoDescripcion,
                'latitud' => $encabezadoLatitud,
                'longitud' => $encabezadoLongitud,
                'foto' => $encabezadoFoto,
                'audio' => $encabezadoAudio,
            );
            
            //Llamo metodo add para hacer insert del sitio a grbara
            $api->add($item);
            
        }catch(Exception $e){
            // preparamos el mensaje como objeto json
            $response["msg"] = " No logramos guardar el sitio";
        }
        
    }else
    {
        $api->error("Error al consumir el API");
    }
?>
