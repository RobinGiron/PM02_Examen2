<?php

include_once 'sitios.php';

class ApiSitios{

    function getAll(){
        $sitio = new Sitios();
        $sitios = array();
        $sitios["items"] = array();

        $res = $sitio->getSitios();

        if($res->rowCount()){
            while ($row = $res->fetch(PDO::FETCH_ASSOC)){
    
                $item=array(
                    "Id" => $row['id'],
                    "Descripcion" => $row['descripcion'],
                    "Latitud" => $row['latitud'],
                    "Longitud" => $row['longitud'],
                    "Foto" => $row['foto'],
                    "Audio" => $row['audio'],                    
                );
                array_push($sitios["items"], $item);
            }
        
            echo json_encode($sitios);

        }else{
            echo json_encode(array('msg' => 'No hay elementos'));
        }
    }

    function getById($id){
        $sitio = new Sitios();
        $sitios = array();
        $sitios["items"] = array();

        $res = $sitio->getSitiosById($id);

        if($res->rowCount() == 1){
            $row = $res->fetch();
        
            $item=array(
                "Id" => $row['id'],
                "Descripcion" => $row['descripcion'],
                "Latitud" => $row['latitud'],
                "Longitud" => $row['longitud'],
                "Foto" => $row['foto'],
                "Audio" => $row['audio'],                    
            );
            array_push($sitios["items"], $item);
            $this->printJSON($sitios);
        }else{
            echo json_encode(array('msg' => 'No hay elementos'));
        }
    }

    //Funcion para agregar mis sitios
    function add($item){
        $sitio = new Sitios();
        $res = $sitio->addSitio($item);
        $this->exito('Sitio Agregado con exito');  
    }
    //Funcion para modificar mis sitios
    function upd($item){
        $sitio = new Sitios();
        $res = $sitio->updSitio($item);
        $this->exito('Sitio modificado con exito');  
    }

    //Funcion para modificar mis usuarios
    function del($item){
        $sitio = new Sitios();
        $res = $sitio->delSitio($item);
        $this->exito('Sitio eliminado');  
    }

    function error($mensaje){
        echo json_encode(array('msg' => $mensaje)); 
    }

    function exito($mensaje){
        echo json_encode(array('msg' => $mensaje)); 
    }

    function printJSON($array){
        echo '<code>'.json_encode($array).'</code>';
    }
}

?>