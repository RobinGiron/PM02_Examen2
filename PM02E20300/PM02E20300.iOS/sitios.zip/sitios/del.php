<?php

header("Content-Type: application/x-www-form-urlencoded");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'apiSitios.php';
$api = new ApiSitios();

if($_SERVER['REQUEST_METHOD'] == "POST"){
    //Codigo nuevo
    $data   = json_decode(file_get_contents( "php://input" ),true);
    try{
    //Mapeo los datos de mi JSON recibido
    $encabezadoId = $data["Id"];
    $item = array(
        'id' => $encabezadoId
    );
    $api->del($item);
            
    }catch(Exception $e){
        // preparamos el mensaje como objeto json
        $response["msg"] = " No pudimos eliminar";
    }
    }else
    {
        $api->error("Error al consumir el API");
    }
    
?>
