<?php

    header("Content-Type: application/json; charset=UTF-8");

    include_once 'apiSitios.php';

    $api = new ApiSitios();

//Validamos el tipo de peticion, si la variable id esta definidida buscamos un usarios
//en especifico, caso contrario devolvemos todo

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $api->getById($id);
}else{
    $api->getAll();
}
  
?>
