<?php

include_once 'db.php';

class Sitios extends DB{
    
    //Obtengo todos los clientes
    function getSitios(){
        $query = $this->connect()->query('SELECT * FROM sitios');
        return $query;
    }

    //Obtengo 1 cliente en especifico

    function getSitiosById($Id){
        $query = $this->connect()->prepare('SELECT * FROM sitios WHERE id = :Id');
        $query->execute(['Id' => $Id]);
        return $query;

    }

    //Para la funcion de agregar vamos a declarar el $sitio como array
    function addSitio($sitio){
        $query = $this->connect()->prepare(
            'INSERT INTO sitios (
                descripcion, 
                latitud, 
                longitud, 
                foto, 
                audio) VALUES (
                :descripcion, 
                :latitud, 
                :longitud, 
                :foto, 
                :audio)
                ');
        $query->execute([
            
            'descripcion' =>  $sitio['descripcion'],
            'latitud' => $sitio['latitud'],
            'longitud' => $sitio['longitud'],
            'foto' => $sitio['foto'],
            'audio' => $sitio['audio']]);

        return $query;
    }

    function updSitio($sitio){
        $query = $this->connect()->prepare('UPDATE sitios SET 
        
        descripcion = :descripcion , 
        latitud = :latitud, 
        longitud = :longitud,
        foto = :foto, 
        audio = :audio 
        WHERE 
        id = :id'
        );

        $query->execute([
            'id' => $sitio['id'],
            'descripcion' => $sitio['descripcion'],
            'latitud' => $sitio['latitud'],
            'longitud' => $sitio['longitud'],
            'foto' => $sitio['foto'],
            'audio' => $sitio['audio']]);
        return $query;
    }

    function delSitio($sitio){
        $query = $this->connect()->prepare('DELETE FROM sitios WHERE  id = :id');
        $query->execute([
            'id' => $sitio['id']]);
        return $query;
    }

  
}

?>
